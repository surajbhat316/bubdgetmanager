<?php
  require_once "pdo.php";
  session_start();

 ?>
